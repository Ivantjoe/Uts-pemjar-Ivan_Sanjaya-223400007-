module laundry-kos

go 1.25.1
