
package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net"
	"strings"
	"sync"
)

const (
	statusProses = "diproses"
	statusSiap   = "siap_diambil"
	statusAmbil  = "sudah_diambil"
)

type Laundry struct {
	ID        int    `json:"id"`
	Nota      string `json:"nota"`
	Pelanggan string `json:"pelanggan"`
	Status    string `json:"status"`
}

type Store struct {
	mu     sync.Mutex
	items  []Laundry
	nextID int
}

func newStore() *Store {
	return &Store{nextID: 1}
}

func (s *Store) create(nota, pelanggan string) (Laundry, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	for _, it := range s.items {
		if strings.EqualFold(it.Nota, nota) {
			return Laundry{}, errors.New("nomor nota sudah digunakan")
		}
	}

	it := Laundry{
		ID:        s.nextID,
		Nota:      nota,
		Pelanggan: pelanggan,
		Status:    statusProses,
	}

	s.nextID++
	s.items = append(s.items, it)

	return it, nil
}

func (s *Store) list(status string) []Laundry {
	s.mu.Lock()
	defer s.mu.Unlock()

	out := []Laundry{}

	for _, it := range s.items {
		if status == "" || it.Status == status {
			out = append(out, it)
		}
	}

	return out
}

func (s *Store) get(nota string) (Laundry, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	for _, it := range s.items {
		if strings.EqualFold(it.Nota, nota) {
			return it, nil
		}
	}

	return Laundry{}, errors.New("nota tidak ditemukan")
}

// Mengubah status menjadi siap diambil
func (s *Store) selesaikan(nota string) (Laundry, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	for i := range s.items {
		if strings.EqualFold(s.items[i].Nota, nota) {
			if s.items[i].Status != statusProses {
				return Laundry{}, errors.New("cucian bukan dalam status diproses")
			}

			s.items[i].Status = statusSiap
			return s.items[i], nil
		}
	}

	return Laundry{}, errors.New("nota tidak ditemukan")
}

func (s *Store) ambil(nota string) (Laundry, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	for i := range s.items {
		if strings.EqualFold(s.items[i].Nota, nota) {
			if s.items[i].Status != statusSiap {
				return Laundry{}, errors.New("cucian belum siap diambil")
			}

			s.items[i].Status = statusAmbil
			return s.items[i], nil
		}
	}

	return Laundry{}, errors.New("nota tidak ditemukan")
}

func (s *Store) hapus(nota string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	for i, it := range s.items {
		if strings.EqualFold(it.Nota, nota) {
			if it.Status == statusAmbil {
				return errors.New("cucian yang sudah diambil tidak boleh dihapus")
			}

			s.items = append(s.items[:i], s.items[i+1:]...)
			return nil
		}
	}

	return errors.New("nota tidak ditemukan")
}

func kirim(conn net.Conn, data any) {
	jsonData, err := json.Marshal(data)
	if err != nil {
		fmt.Fprintln(conn, `{"galat":"gagal membuat JSON"}`)
		return
	}

	fmt.Fprintln(conn, string(jsonData))
}

func prosesPerintah(conn net.Conn, scanner *bufio.Scanner, s *Store) {
	fmt.Fprintln(conn, "Perintah yang tersedia:")
	fmt.Fprintln(conn, "BUAT <nota> <pelanggan>")
	fmt.Fprintln(conn, "DAFTAR")
	fmt.Fprintln(conn, "DAFTAR <status>")
	fmt.Fprintln(conn, "LIHAT <nota>")
	fmt.Fprintln(conn, "SELESAIKAN <nota>")
	fmt.Fprintln(conn, "AMBIL <nota>")
	fmt.Fprintln(conn, "HAPUS <nota>")
	fmt.Fprintln(conn, "KELUAR")

	for scanner.Scan() {
		pesan := strings.TrimSpace(scanner.Text())

		if pesan == "" {
			continue
		}

		parts := strings.Fields(pesan)
		perintah := strings.ToUpper(parts[0])

		switch perintah {

		case "BUAT":
			if len(parts) < 3 {
				fmt.Fprintln(conn, "Format: BUAT <nota> <pelanggan>")
				continue
			}

			nota := parts[1]
			pelanggan := strings.Join(parts[2:], " ")

			it, err := s.create(nota, pelanggan)
			if err != nil {
				kirim(conn, map[string]string{"galat": err.Error()})
				continue
			}

			kirim(conn, it)

		case "DAFTAR":
			status := ""

			if len(parts) == 2 {
				status = strings.ToLower(parts[1])

				if status != statusProses &&
					status != statusSiap &&
					status != statusAmbil {
					fmt.Fprintln(conn, "Status tidak dikenal")
					continue
				}
			} else if len(parts) > 2 {
				fmt.Fprintln(conn, "Format: DAFTAR [status]")
				continue
			}

			data := s.list(status)
			kirim(conn, map[string]any{
				"jumlah": len(data),
				"data":   data,
			})
		case "LIHAT":
			if len(parts) != 2 {
				fmt.Fprintln(conn, "Format: LIHAT <nota>")
				continue
			}
			it, err := s.get(parts[1])
			if err != nil {
				kirim(conn, map[string]string{"galat": err.Error()})
				continue
			}
			kirim(conn, it)
		case "SELESAIKAN":
			if len(parts) != 2 {
				fmt.Fprintln(conn, "Format: SELESAIKAN <nota>")
				continue
			}
			it, err := s.selesaikan(parts[1])
			if err != nil {
				kirim(conn, map[string]string{"galat": err.Error()})
				continue
			}
			kirim(conn, it)
		case "AMBIL":
			if len(parts) != 2 {
				fmt.Fprintln(conn, "Format: AMBIL <nota>")
				continue
			}
			it, err := s.ambil(parts[1])
			if err != nil {
				kirim(conn, map[string]string{"galat": err.Error()})
				continue
			}
			kirim(conn, it)
		case "HAPUS":
			if len(parts) != 2 {
				fmt.Fprintln(conn, "Format: HAPUS <nota>")
				continue
			}
			err := s.hapus(parts[1])
			if err != nil {
				kirim(conn, map[string]string{"galat": err.Error()})
				continue
			}
			kirim(conn, map[string]string{"status": "data berhasil dihapus"})
		case "KELUAR":
			fmt.Fprintln(conn, "Koneksi ditutup")
			return
		default:
			fmt.Fprintln(conn, "Perintah tidak dikenal")
		}
	}
}

func layani(conn net.Conn, s *Store) {
	defer conn.Close()
	alamat := conn.RemoteAddr().String()
	log.Println("Client terhubung:", alamat)
	scanner := bufio.NewScanner(conn)
	fmt.Fprintln(conn, "Selamat datang di Sistem Pencatatan Laundry Kos!")
	prosesPerintah(conn, scanner, s)
	log.Println("Client terputus:", alamat)
}

func main() {
	ln, err := net.Listen("tcp", ":199")
	if err != nil {
		log.Fatal("Gagal membuka port 199:", err)
	}
	defer ln.Close()
	log.Println("Server Pencatatan Laundry Kos berjalan di port 199")
	s := newStore()

	for {
		conn, err := ln.Accept()
		if err != nil {
			log.Println("Gagal menerima koneksi:", err)
			continue
		}
		go layani(conn, s)
	}
}
