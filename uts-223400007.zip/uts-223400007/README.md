Saya memakai Ai ChatGPT untuk 
1. Memperbaiki codingan yang error agar program dapat berjalan dengan baik
2. Merapihkan codingan agar lebih terstuktur
3. Membantu saya untuk memahami fungsi disetiap bagian codingan serta menjalankan program klien dan server 
4. Membantu memperbaiki komunikasi TCP antara Klien dan Server agar dapat mengirim dan menerima pesan
